var krms_config ={			
	'ApiUrl' : "http://bastisapp.com/kmrs/merchantapp/api",	
	'DialogDefaultTitle' : "KMRS",
	'pushNotificationSenderid' : "309055650516",
	'APIHasKey' : ""
};
